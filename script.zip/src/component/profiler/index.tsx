import ChatContainer from "./chat-container";

export default function Profiler() {
    return <ChatContainer/>
}