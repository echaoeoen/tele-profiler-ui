import Profiler from "@/component/profiler"

export default function ProfilerPage() {
    return <Profiler/>
}